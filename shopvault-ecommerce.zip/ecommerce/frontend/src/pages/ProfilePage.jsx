import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { getErrorMessage } from '../utils/helpers';
import toast from 'react-hot-toast';
import { User, Lock } from 'lucide-react';

export default function ProfilePage() {
  const { user, updateProfile } = useAuth();
  const [form, setForm] = useState({ name: user?.name || '', email: user?.email || '' });
  const [pwForm, setPwForm] = useState({ currentPassword: '', password: '', confirm: '' });
  const [saving, setSaving] = useState(false);
  const [savingPw, setSavingPw] = useState(false);

  const handleChange = (e) => setForm((f) => ({ ...f, [e.target.name]: e.target.value }));
  const handlePwChange = (e) => setPwForm((f) => ({ ...f, [e.target.name]: e.target.value }));

  const handleProfileSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await updateProfile(form);
      toast.success('Profile updated!');
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally { setSaving(false); }
  };

  const handlePasswordSave = async (e) => {
    e.preventDefault();
    if (pwForm.password !== pwForm.confirm) { toast.error('Passwords do not match'); return; }
    setSavingPw(true);
    try {
      await updateProfile({ password: pwForm.password, currentPassword: pwForm.currentPassword });
      toast.success('Password updated!');
      setPwForm({ currentPassword: '', password: '', confirm: '' });
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally { setSavingPw(false); }
  };

  return (
    <div className="page">
      <div className="container-sm">
        <div className="page-header">
          <h1 className="page-title">My Profile</h1>
          <p className="page-subtitle">Manage your account details</p>
        </div>

        <div style={{ display: 'grid', gap: 20 }}>
          {/* Profile info */}
          <div className="card" style={{ padding: 24 }}>
            <h2 style={{ fontSize: 17, marginBottom: 20, display: 'flex', alignItems: 'center', gap: 8 }}>
              <User size={18} /> Personal Information
            </h2>
            <form onSubmit={handleProfileSave} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              <div className="form-group">
                <label className="form-label">Full Name</label>
                <input name="name" className="form-input" value={form.name} onChange={handleChange} required />
              </div>
              <div className="form-group">
                <label className="form-label">Email</label>
                <input name="email" type="email" className="form-input" value={form.email} onChange={handleChange} required />
              </div>
              <div className="form-group">
                <label className="form-label">Role</label>
                <input className="form-input" value={user?.role} disabled style={{ opacity: 0.5 }} />
              </div>
              <button type="submit" className="btn btn-primary" disabled={saving} style={{ alignSelf: 'flex-start' }}>
                {saving ? 'Saving…' : 'Save Changes'}
              </button>
            </form>
          </div>

          {/* Change password */}
          <div className="card" style={{ padding: 24 }}>
            <h2 style={{ fontSize: 17, marginBottom: 20, display: 'flex', alignItems: 'center', gap: 8 }}>
              <Lock size={18} /> Change Password
            </h2>
            <form onSubmit={handlePasswordSave} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              <div className="form-group">
                <label className="form-label">Current Password</label>
                <input name="currentPassword" type="password" className="form-input" value={pwForm.currentPassword} onChange={handlePwChange} required />
              </div>
              <div className="form-group">
                <label className="form-label">New Password</label>
                <input name="password" type="password" className="form-input" value={pwForm.password} onChange={handlePwChange} required />
              </div>
              <div className="form-group">
                <label className="form-label">Confirm New Password</label>
                <input name="confirm" type="password" className="form-input" value={pwForm.confirm} onChange={handlePwChange} required />
              </div>
              <button type="submit" className="btn btn-outline" disabled={savingPw} style={{ alignSelf: 'flex-start' }}>
                {savingPw ? 'Updating…' : 'Update Password'}
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
