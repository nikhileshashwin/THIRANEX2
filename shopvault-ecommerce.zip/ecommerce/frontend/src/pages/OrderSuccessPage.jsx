import React, { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { CheckCircle, Package } from 'lucide-react';
import api from '../utils/api';
import { formatPrice, formatDateTime } from '../utils/helpers';

export default function OrderSuccessPage() {
  const { id } = useParams();
  const [order, setOrder] = useState(null);

  useEffect(() => {
    api.get(`/orders/${id}`).then(({ data }) => setOrder(data)).catch(() => {});
  }, [id]);

  return (
    <div className="page">
      <div className="container-sm" style={{ textAlign: 'center', paddingTop: 60 }}>
        <CheckCircle size={64} color="var(--green)" style={{ margin: '0 auto 20px' }} />
        <h1 style={{ fontSize: 36, marginBottom: 10 }}>Order Confirmed!</h1>
        <p style={{ color: 'var(--text-2)', marginBottom: 32 }}>
          Thanks for your purchase. We'll send a confirmation shortly.
        </p>
        {order && (
          <div className="card" style={{ padding: 24, textAlign: 'left', marginBottom: 28 }}>
            <p style={{ fontWeight: 700, marginBottom: 6 }}>Order #{order._id.slice(-8).toUpperCase()}</p>
            <p style={{ fontSize: 13, color: 'var(--text-3)', marginBottom: 16 }}>{formatDateTime(order.createdAt)}</p>
            {order.orderItems.map((item) => (
              <div key={item._id} style={{ display: 'flex', gap: 12, marginBottom: 12, alignItems: 'center' }}>
                <img src={item.image} alt={item.name} style={{ width: 48, height: 48, borderRadius: 8, objectFit: 'cover' }} />
                <div style={{ flex: 1 }}>
                  <p style={{ fontSize: 14, fontWeight: 500 }}>{item.name}</p>
                  <p style={{ fontSize: 12, color: 'var(--text-3)' }}>Qty: {item.quantity}</p>
                </div>
                <p style={{ fontFamily: 'var(--font-display)', fontWeight: 700 }}>{formatPrice(item.price * item.quantity)}</p>
              </div>
            ))}
            <div style={{ height: 1, background: 'var(--border)', margin: '16px 0' }} />
            <div style={{ display: 'flex', justifyContent: 'space-between', fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 17 }}>
              <span>Total</span><span>{formatPrice(order.totalPrice)}</span>
            </div>
          </div>
        )}
        <div style={{ display: 'flex', gap: 12, justifyContent: 'center' }}>
          <Link to="/orders" className="btn btn-primary"><Package size={16} /> My Orders</Link>
          <Link to="/products" className="btn btn-outline">Continue Shopping</Link>
        </div>
      </div>
    </div>
  );
}
