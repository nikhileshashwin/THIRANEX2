import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Package, ShoppingBag, Users, DollarSign, ArrowRight, TrendingUp } from 'lucide-react';
import api from '../utils/api';
import { formatPrice, formatDate, getOrderStatusColor } from '../utils/helpers';
import './AdminPages.css';

export default function AdminDashboard() {
  const [stats, setStats] = useState(null);
  const [recentOrders, setRecentOrders] = useState([]);
  const [productCount, setProductCount] = useState(0);
  const [userStats, setUserStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      try {
        const [orderStats, orders, products, users] = await Promise.all([
          api.get('/orders/stats'),
          api.get('/orders?limit=5'),
          api.get('/products/admin/all?limit=1'),
          api.get('/users/stats'),
        ]);
        setStats(orderStats.data);
        setRecentOrders(orders.data.orders);
        setProductCount(products.data.total);
        setUserStats(users.data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  if (loading) return <div className="loading-center"><div className="spinner" /></div>;

  const totalOrders = stats?.byStatus?.reduce((a, s) => a + s.count, 0) || 0;

  const summaryCards = [
    { label: 'Total Revenue', value: formatPrice(stats?.totalRevenue || 0), icon: <DollarSign size={22} />, color: 'green', link: '/admin/orders' },
    { label: 'Total Orders', value: totalOrders, icon: <ShoppingBag size={22} />, color: 'blue', link: '/admin/orders' },
    { label: 'Products', value: productCount, icon: <Package size={22} />, color: 'yellow', link: '/admin/products' },
    { label: 'Users', value: userStats?.total || 0, icon: <Users size={22} />, color: 'red', link: '/admin/users' },
  ];

  return (
    <div className="page admin-page">
      <div className="container">
        <div className="admin-header">
          <div>
            <h1 className="page-title">Dashboard</h1>
            <p className="page-subtitle">Welcome back, Admin</p>
          </div>
          <div style={{ display: 'flex', gap: 10 }}>
            <Link to="/admin/products/new" className="btn btn-primary btn-sm">+ Add Product</Link>
          </div>
        </div>

        {/* Summary cards */}
        <div className="stats-grid">
          {summaryCards.map((card) => (
            <Link key={card.label} to={card.link} className={`stat-card stat-${card.color}`}>
              <div className="stat-icon">{card.icon}</div>
              <div>
                <p className="stat-value">{card.value}</p>
                <p className="stat-label">{card.label}</p>
              </div>
              <ArrowRight size={16} className="stat-arrow" />
            </Link>
          ))}
        </div>

        {/* Order status breakdown */}
        {stats?.byStatus?.length > 0 && (
          <div className="admin-section">
            <h2>Orders by Status</h2>
            <div className="status-grid">
              {stats.byStatus.map((s) => (
                <div key={s._id} className="status-card card">
                  <span className={`badge ${getOrderStatusColor(s._id)}`}>{s._id}</span>
                  <p className="status-count">{s.count}</p>
                  <p className="status-revenue">{formatPrice(s.revenue)}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Recent orders */}
        <div className="admin-section">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
            <h2>Recent Orders</h2>
            <Link to="/admin/orders" className="btn btn-ghost btn-sm">View All <ArrowRight size={14} /></Link>
          </div>
          <div className="card">
            <table className="admin-table">
              <thead>
                <tr>
                  <th>Order ID</th>
                  <th>Customer</th>
                  <th>Date</th>
                  <th>Status</th>
                  <th>Total</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {recentOrders.map((order) => (
                  <tr key={order._id}>
                    <td><code className="order-id">#{order._id.slice(-8).toUpperCase()}</code></td>
                    <td>{order.user?.name || '—'}</td>
                    <td style={{ color: 'var(--text-3)', fontSize: 13 }}>{formatDate(order.createdAt)}</td>
                    <td><span className={`badge ${getOrderStatusColor(order.status)}`}>{order.status}</span></td>
                    <td style={{ fontFamily: 'var(--font-display)', fontWeight: 700 }}>{formatPrice(order.totalPrice)}</td>
                    <td><Link to={`/orders/${order._id}`} className="btn btn-ghost btn-sm">View</Link></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
