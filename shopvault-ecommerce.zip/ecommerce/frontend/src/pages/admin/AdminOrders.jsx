import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Eye, ChevronDown } from 'lucide-react';
import api from '../utils/api';
import { formatPrice, formatDate, getOrderStatusColor } from '../utils/helpers';
import toast from 'react-hot-toast';
import './AdminPages.css';

const STATUSES = ['pending', 'processing', 'shipped', 'delivered', 'cancelled'];

export default function AdminOrders() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [pages, setPages] = useState(1);
  const [statusFilter, setStatusFilter] = useState('');
  const [updatingId, setUpdatingId] = useState(null);

  const fetchOrders = async (p = 1, status = statusFilter) => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ page: p, limit: 15 });
      if (status) params.set('status', status);
      const { data } = await api.get(`/orders?${params}`);
      setOrders(data.orders);
      setPages(data.pages);
    } catch {}
    finally { setLoading(false); }
  };

  useEffect(() => { fetchOrders(page, statusFilter); }, [page, statusFilter]);

  const handleStatusChange = async (orderId, newStatus) => {
    setUpdatingId(orderId);
    try {
      await api.put(`/orders/${orderId}/status`, { status: newStatus });
      toast.success(`Order marked as ${newStatus}`);
      setOrders((prev) =>
        prev.map((o) => (o._id === orderId ? { ...o, status: newStatus } : o))
      );
    } catch (err) {
      toast.error(err?.response?.data?.message || 'Update failed');
    } finally {
      setUpdatingId(null);
    }
  };

  return (
    <div className="page admin-page">
      <div className="container">
        <div className="admin-header">
          <div>
            <h1 className="page-title">Orders</h1>
            <p className="page-subtitle">Manage and track all customer orders</p>
          </div>
        </div>

        {/* Filters */}
        <div style={{ display: 'flex', gap: 8, marginBottom: 20, flexWrap: 'wrap' }}>
          <button
            className={`filter-chip ${!statusFilter ? 'active' : ''}`}
            onClick={() => { setStatusFilter(''); setPage(1); }}
          >All</button>
          {STATUSES.map((s) => (
            <button
              key={s}
              className={`filter-chip ${statusFilter === s ? 'active' : ''}`}
              onClick={() => { setStatusFilter(s); setPage(1); }}
            >{s.charAt(0).toUpperCase() + s.slice(1)}</button>
          ))}
        </div>

        <div className="card">
          {loading ? (
            <div className="loading-center" style={{ minHeight: 200 }}><div className="spinner" /></div>
          ) : orders.length === 0 ? (
            <div style={{ padding: '40px', textAlign: 'center', color: 'var(--text-3)' }}>No orders found.</div>
          ) : (
            <table className="admin-table">
              <thead>
                <tr>
                  <th>Order ID</th>
                  <th>Customer</th>
                  <th>Date</th>
                  <th>Items</th>
                  <th>Total</th>
                  <th>Payment</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {orders.map((order) => (
                  <tr key={order._id}>
                    <td>
                      <code className="order-id">#{order._id.slice(-8).toUpperCase()}</code>
                    </td>
                    <td>
                      <div>
                        <p style={{ fontWeight: 600, fontSize: 13 }}>{order.user?.name || '—'}</p>
                        <p style={{ fontSize: 11, color: 'var(--text-3)' }}>{order.user?.email}</p>
                      </div>
                    </td>
                    <td style={{ color: 'var(--text-3)', fontSize: 13 }}>{formatDate(order.createdAt)}</td>
                    <td style={{ color: 'var(--text-2)', fontSize: 13 }}>{order.orderItems?.length} item(s)</td>
                    <td style={{ fontFamily: 'var(--font-display)', fontWeight: 700 }}>
                      {formatPrice(order.totalPrice)}
                    </td>
                    <td>
                      <span className={`badge ${order.isPaid ? 'badge-green' : 'badge-yellow'}`} style={{ fontSize: 11 }}>
                        {order.isPaid ? 'Paid' : 'Unpaid'}
                      </span>
                    </td>
                    <td>
                      <div className="status-select-wrap">
                        <select
                          className="status-select"
                          value={order.status}
                          disabled={updatingId === order._id}
                          onChange={(e) => handleStatusChange(order._id, e.target.value)}
                        >
                          {STATUSES.map((s) => (
                            <option key={s} value={s}>{s.charAt(0).toUpperCase() + s.slice(1)}</option>
                          ))}
                        </select>
                        <ChevronDown size={12} className="status-select-icon" />
                      </div>
                    </td>
                    <td>
                      <Link to={`/orders/${order._id}`} className="btn btn-ghost btn-sm">
                        <Eye size={14} /> View
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        {pages > 1 && (
          <div style={{ display: 'flex', justifyContent: 'center', gap: 8, marginTop: 24 }}>
            {Array.from({ length: pages }, (_, i) => i + 1).map((p) => (
              <button
                key={p}
                className={`page-btn ${page === p ? 'active' : ''}`}
                onClick={() => setPage(p)}
              >{p}</button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
