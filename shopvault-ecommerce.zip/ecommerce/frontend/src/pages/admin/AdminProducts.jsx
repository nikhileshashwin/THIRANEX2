import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Plus, Pencil, Trash2, Search } from 'lucide-react';
import api from '../utils/api';
import { formatPrice, formatDate } from '../utils/helpers';
import toast from 'react-hot-toast';
import './AdminPages.css';

export default function AdminProducts() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [pages, setPages] = useState(1);

  const fetchProducts = async (p = 1) => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ page: p, limit: 15 });
      const { data } = await api.get(`/products/admin/all?${params}`);
      setProducts(data.products);
      setPages(data.pages);
    } catch {}
    finally { setLoading(false); }
  };

  useEffect(() => { fetchProducts(page); }, [page]);

  const handleDelete = async (id, name) => {
    if (!window.confirm(`Delete "${name}"?`)) return;
    try {
      await api.delete(`/products/${id}`);
      toast.success('Product deleted');
      fetchProducts(page);
    } catch (err) {
      toast.error(err?.response?.data?.message || 'Delete failed');
    }
  };

  const filtered = products.filter(p =>
    p.name.toLowerCase().includes(search.toLowerCase()) ||
    p.brand.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="page admin-page">
      <div className="container">
        <div className="admin-header">
          <div>
            <h1 className="page-title">Products</h1>
            <p className="page-subtitle">Manage your product catalog</p>
          </div>
          <Link to="/admin/products/new" className="btn btn-primary">
            <Plus size={16} /> Add Product
          </Link>
        </div>

        {/* Search bar */}
        <div style={{ position: 'relative', marginBottom: 20, maxWidth: 320 }}>
          <Search size={15} style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-3)' }} />
          <input
            className="form-input"
            style={{ paddingLeft: 36 }}
            placeholder="Search products…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        <div className="card">
          {loading ? (
            <div className="loading-center" style={{ minHeight: 200 }}><div className="spinner" /></div>
          ) : (
            <table className="admin-table">
              <thead>
                <tr>
                  <th>Product</th>
                  <th>Category</th>
                  <th>Price</th>
                  <th>Stock</th>
                  <th>Status</th>
                  <th>Created</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((p) => (
                  <tr key={p._id}>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                        <img src={p.images?.[0]} alt={p.name} className="product-img-sm" />
                        <div>
                          <p style={{ fontWeight: 600, fontSize: 13, maxWidth: 200, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{p.name}</p>
                          <p style={{ fontSize: 11, color: 'var(--text-3)' }}>{p.brand}</p>
                        </div>
                      </div>
                    </td>
                    <td><span className="badge badge-gray" style={{ fontSize: 11 }}>{p.category}</span></td>
                    <td style={{ fontFamily: 'var(--font-display)', fontWeight: 700 }}>{formatPrice(p.price)}</td>
                    <td>
                      <span style={{ color: p.stock < 10 ? 'var(--red)' : p.stock < 20 ? 'var(--accent)' : 'var(--green)', fontWeight: 600 }}>
                        {p.stock}
                      </span>
                    </td>
                    <td>
                      <span className={`badge ${p.isActive ? 'badge-green' : 'badge-red'}`} style={{ fontSize: 11 }}>
                        {p.isActive ? 'Active' : 'Hidden'}
                      </span>
                    </td>
                    <td style={{ color: 'var(--text-3)', fontSize: 13 }}>{formatDate(p.createdAt)}</td>
                    <td>
                      <div style={{ display: 'flex', gap: 6 }}>
                        <Link to={`/admin/products/${p._id}/edit`} className="btn btn-outline btn-sm">
                          <Pencil size={13} />
                        </Link>
                        <button className="btn btn-danger btn-sm" onClick={() => handleDelete(p._id, p.name)}>
                          <Trash2 size={13} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        {pages > 1 && (
          <div style={{ display: 'flex', justifyContent: 'center', gap: 8, marginTop: 24 }}>
            {Array.from({ length: pages }, (_, i) => i + 1).map((p) => (
              <button key={p} className={`page-btn ${page === p ? 'active' : ''}`} onClick={() => setPage(p)}>{p}</button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
