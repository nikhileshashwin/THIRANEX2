import React, { useEffect, useState } from 'react';
import { useNavigate, useParams, Link } from 'react-router-dom';
import { ArrowLeft, Plus, X } from 'lucide-react';
import api from '../utils/api';
import { getErrorMessage } from '../utils/helpers';
import toast from 'react-hot-toast';
import './AdminPages.css';

const CATEGORIES = ['Electronics', 'Fashion', 'Sports', 'Home & Kitchen', 'Books', 'Toys', 'Other'];

const EMPTY = {
  name: '', description: '', price: '', compareAtPrice: '',
  category: 'Electronics', brand: '', stock: '', sku: '',
  images: [''], isFeatured: false, isActive: true,
};

export default function AdminProductForm() {
  const { id } = useParams();
  const navigate = useNavigate();
  const isEdit = Boolean(id);

  const [form, setForm] = useState(EMPTY);
  const [loading, setLoading] = useState(isEdit);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!isEdit) return;
    api.get(`/products/${id}`)
      .then(({ data }) => {
        setForm({
          name: data.name,
          description: data.description,
          price: data.price,
          compareAtPrice: data.compareAtPrice || '',
          category: data.category,
          brand: data.brand,
          stock: data.stock,
          sku: data.sku || '',
          images: data.images?.length ? data.images : [''],
          isFeatured: data.isFeatured,
          isActive: data.isActive,
        });
      })
      .catch(() => toast.error('Failed to load product'))
      .finally(() => setLoading(false));
  }, [id, isEdit]);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setForm((f) => ({ ...f, [name]: type === 'checkbox' ? checked : value }));
  };

  const handleImageChange = (i, val) => {
    setForm((f) => {
      const imgs = [...f.images];
      imgs[i] = val;
      return { ...f, images: imgs };
    });
  };

  const addImage = () => setForm((f) => ({ ...f, images: [...f.images, ''] }));
  const removeImage = (i) => setForm((f) => ({ ...f, images: f.images.filter((_, idx) => idx !== i) }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      const payload = {
        ...form,
        price: parseFloat(form.price),
        compareAtPrice: form.compareAtPrice ? parseFloat(form.compareAtPrice) : null,
        stock: parseInt(form.stock),
        images: form.images.filter(Boolean),
      };
      if (isEdit) {
        await api.put(`/products/${id}`, payload);
        toast.success('Product updated!');
      } else {
        await api.post('/products', payload);
        toast.success('Product created!');
      }
      navigate('/admin/products');
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <div className="loading-center"><div className="spinner" /></div>;

  return (
    <div className="page admin-page">
      <div className="container-sm">
        <Link to="/admin/products" className="back-link" style={{ display: 'inline-flex', alignItems: 'center', gap: 6, fontSize: 14, color: 'var(--text-2)', marginBottom: 24 }}>
          <ArrowLeft size={15} /> Back to Products
        </Link>

        <h1 className="page-title" style={{ marginBottom: 28 }}>{isEdit ? 'Edit Product' : 'Add New Product'}</h1>

        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
          {/* Basic info */}
          <div className="card" style={{ padding: 24 }}>
            <h3 style={{ marginBottom: 20 }}>Basic Information</h3>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
              <div className="form-group" style={{ gridColumn: '1 / -1' }}>
                <label className="form-label">Product Name *</label>
                <input name="name" className="form-input" value={form.name} onChange={handleChange} required placeholder="e.g. Wireless Headphones Pro" />
              </div>
              <div className="form-group">
                <label className="form-label">Brand *</label>
                <input name="brand" className="form-input" value={form.brand} onChange={handleChange} required placeholder="e.g. SoundWave" />
              </div>
              <div className="form-group">
                <label className="form-label">Category *</label>
                <select name="category" className="form-select" value={form.category} onChange={handleChange}>
                  {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
              <div className="form-group" style={{ gridColumn: '1 / -1' }}>
                <label className="form-label">Description *</label>
                <textarea name="description" className="form-input" value={form.description} onChange={handleChange} required rows={4} placeholder="Describe the product…" />
              </div>
            </div>
          </div>

          {/* Pricing & Stock */}
          <div className="card" style={{ padding: 24 }}>
            <h3 style={{ marginBottom: 20 }}>Pricing & Inventory</h3>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr 1fr', gap: 16 }}>
              <div className="form-group">
                <label className="form-label">Price ($) *</label>
                <input name="price" type="number" min="0" step="0.01" className="form-input" value={form.price} onChange={handleChange} required placeholder="0.00" />
              </div>
              <div className="form-group">
                <label className="form-label">Compare At ($)</label>
                <input name="compareAtPrice" type="number" min="0" step="0.01" className="form-input" value={form.compareAtPrice} onChange={handleChange} placeholder="0.00" />
              </div>
              <div className="form-group">
                <label className="form-label">Stock *</label>
                <input name="stock" type="number" min="0" className="form-input" value={form.stock} onChange={handleChange} required placeholder="0" />
              </div>
              <div className="form-group">
                <label className="form-label">SKU</label>
                <input name="sku" className="form-input" value={form.sku} onChange={handleChange} placeholder="Optional" />
              </div>
            </div>
          </div>

          {/* Images */}
          <div className="card" style={{ padding: 24 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
              <h3>Images</h3>
              <button type="button" className="btn btn-outline btn-sm" onClick={addImage}>
                <Plus size={14} /> Add Image
              </button>
            </div>
            {form.images.map((img, i) => (
              <div key={i} style={{ display: 'flex', gap: 10, marginBottom: 10, alignItems: 'center' }}>
                {img && <img src={img} alt="" style={{ width: 48, height: 48, borderRadius: 6, objectFit: 'cover', border: '1px solid var(--border)', flexShrink: 0 }} onError={(e) => e.target.style.display = 'none'} />}
                <input
                  className="form-input"
                  value={img}
                  onChange={(e) => handleImageChange(i, e.target.value)}
                  placeholder="https://example.com/image.jpg"
                />
                {form.images.length > 1 && (
                  <button type="button" className="btn btn-danger btn-sm" onClick={() => removeImage(i)}>
                    <X size={13} />
                  </button>
                )}
              </div>
            ))}
          </div>

          {/* Settings */}
          <div className="card" style={{ padding: 24 }}>
            <h3 style={{ marginBottom: 16 }}>Settings</h3>
            <div style={{ display: 'flex', gap: 24 }}>
              <label style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer' }}>
                <input type="checkbox" name="isActive" checked={form.isActive} onChange={handleChange} />
                <span style={{ fontSize: 14 }}>Active (visible to customers)</span>
              </label>
              <label style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer' }}>
                <input type="checkbox" name="isFeatured" checked={form.isFeatured} onChange={handleChange} />
                <span style={{ fontSize: 14 }}>Featured on homepage</span>
              </label>
            </div>
          </div>

          <div style={{ display: 'flex', gap: 12, justifyContent: 'flex-end' }}>
            <Link to="/admin/products" className="btn btn-outline">Cancel</Link>
            <button type="submit" className="btn btn-primary btn-lg" disabled={saving}>
              {saving ? 'Saving…' : isEdit ? 'Update Product' : 'Create Product'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
