import React, { useState, useEffect, useCallback } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Search, SlidersHorizontal, X } from 'lucide-react';
import api from '../utils/api';
import ProductCard from '../components/ProductCard';
import './ProductsPage.css';

const SORT_OPTIONS = [
  { value: 'newest', label: 'Newest First' },
  { value: 'rating', label: 'Top Rated' },
  { value: 'price_asc', label: 'Price: Low → High' },
  { value: 'price_desc', label: 'Price: High → Low' },
];

const CATEGORIES = ['Electronics', 'Fashion', 'Sports', 'Home & Kitchen', 'Books', 'Toys', 'Other'];

export default function ProductsPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [total, setTotal] = useState(0);
  const [pages, setPages] = useState(1);
  const [filtersOpen, setFiltersOpen] = useState(false);

  const page = parseInt(searchParams.get('page') || '1');
  const search = searchParams.get('search') || '';
  const category = searchParams.get('category') || '';
  const sort = searchParams.get('sort') || 'newest';
  const minPrice = searchParams.get('minPrice') || '';
  const maxPrice = searchParams.get('maxPrice') || '';

  const fetchProducts = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ page, sort, limit: 12 });
      if (search) params.set('search', search);
      if (category) params.set('category', category);
      if (minPrice) params.set('minPrice', minPrice);
      if (maxPrice) params.set('maxPrice', maxPrice);

      const { data } = await api.get(`/products?${params}`);
      setProducts(data.products);
      setTotal(data.total);
      setPages(data.pages);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [page, search, category, sort, minPrice, maxPrice]);

  useEffect(() => { fetchProducts(); }, [fetchProducts]);

  const updateParam = (key, value) => {
    const next = new URLSearchParams(searchParams);
    if (value) next.set(key, value); else next.delete(key);
    next.set('page', '1');
    setSearchParams(next);
  };

  const clearFilters = () => {
    setSearchParams({ sort: 'newest', page: '1' });
  };

  const hasActiveFilters = category || minPrice || maxPrice || search;

  return (
    <div className="page products-page">
      <div className="container">
        {/* Header */}
        <div className="products-header">
          <div>
            <h1 className="page-title">All Products</h1>
            <p className="page-subtitle">{total} products found</p>
          </div>
          <div className="products-toolbar">
            {/* Search */}
            <div className="search-box">
              <Search size={16} className="search-icon" />
              <input
                type="text"
                placeholder="Search products…"
                className="search-input"
                defaultValue={search}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') updateParam('search', e.target.value);
                }}
              />
            </div>
            {/* Sort */}
            <select
              className="form-select sort-select"
              value={sort}
              onChange={(e) => updateParam('sort', e.target.value)}
            >
              {SORT_OPTIONS.map((o) => (
                <option key={o.value} value={o.value}>{o.label}</option>
              ))}
            </select>
            {/* Mobile filters toggle */}
            <button
              className="btn btn-outline btn-sm filters-toggle"
              onClick={() => setFiltersOpen(!filtersOpen)}
            >
              <SlidersHorizontal size={15} /> Filters
            </button>
          </div>
        </div>

        <div className="products-layout">
          {/* Sidebar Filters */}
          <aside className={`filters-sidebar ${filtersOpen ? 'open' : ''}`}>
            <div className="filters-header">
              <h3>Filters</h3>
              {hasActiveFilters && (
                <button className="btn btn-ghost btn-sm" onClick={clearFilters}>
                  <X size={14} /> Clear
                </button>
              )}
            </div>

            {/* Category */}
            <div className="filter-group">
              <h4>Category</h4>
              <div className="filter-options">
                <button
                  className={`filter-chip ${!category ? 'active' : ''}`}
                  onClick={() => updateParam('category', '')}
                >All</button>
                {CATEGORIES.map((c) => (
                  <button
                    key={c}
                    className={`filter-chip ${category === c ? 'active' : ''}`}
                    onClick={() => updateParam('category', c)}
                  >{c}</button>
                ))}
              </div>
            </div>

            {/* Price */}
            <div className="filter-group">
              <h4>Price Range</h4>
              <div className="price-inputs">
                <input
                  type="number"
                  className="form-input"
                  placeholder="Min"
                  defaultValue={minPrice}
                  onBlur={(e) => updateParam('minPrice', e.target.value)}
                />
                <span>—</span>
                <input
                  type="number"
                  className="form-input"
                  placeholder="Max"
                  defaultValue={maxPrice}
                  onBlur={(e) => updateParam('maxPrice', e.target.value)}
                />
              </div>
            </div>
          </aside>

          {/* Product Grid */}
          <div className="products-main">
            {loading ? (
              <div className="loading-center"><div className="spinner" /></div>
            ) : products.length === 0 ? (
              <div className="empty-state">
                <p>No products found.</p>
                <button className="btn btn-outline btn-sm" onClick={clearFilters}>Clear filters</button>
              </div>
            ) : (
              <>
                <div className="product-grid">
                  {products.map((p) => <ProductCard key={p._id} product={p} />)}
                </div>

                {/* Pagination */}
                {pages > 1 && (
                  <div className="pagination">
                    {Array.from({ length: pages }, (_, i) => i + 1).map((p) => (
                      <button
                        key={p}
                        className={`page-btn ${page === p ? 'active' : ''}`}
                        onClick={() => updateParam('page', p)}
                      >{p}</button>
                    ))}
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
