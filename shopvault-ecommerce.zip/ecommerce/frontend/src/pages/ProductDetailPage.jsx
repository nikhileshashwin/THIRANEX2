import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ShoppingCart, Star, Plus, Minus, ArrowLeft, Package, Shield, Truck } from 'lucide-react';
import api from '../utils/api';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import { formatPrice, formatDate } from '../utils/helpers';
import toast from 'react-hot-toast';
import './ProductDetailPage.css';

export default function ProductDetailPage() {
  const { id } = useParams();
  const { addToCart } = useCart();
  const { user } = useAuth();
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [qty, setQty] = useState(1);
  const [activeImg, setActiveImg] = useState(0);
  const [reviewForm, setReviewForm] = useState({ rating: 5, comment: '' });
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    const fetch = async () => {
      try {
        const { data } = await api.get(`/products/${id}`);
        setProduct(data);
      } catch { toast.error('Product not found'); }
      finally { setLoading(false); }
    };
    fetch();
  }, [id]);

  const handleAddToCart = () => {
    addToCart(product, qty);
  };

  const handleReview = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await api.post(`/products/${id}/reviews`, reviewForm);
      toast.success('Review submitted!');
      const { data } = await api.get(`/products/${id}`);
      setProduct(data);
      setReviewForm({ rating: 5, comment: '' });
    } catch (err) {
      toast.error(err?.response?.data?.message || 'Failed to submit review');
    } finally { setSubmitting(false); }
  };

  if (loading) return <div className="loading-center" style={{ minHeight: '60vh' }}><div className="spinner" /></div>;
  if (!product) return <div className="container" style={{ padding: '60px 0', textAlign: 'center' }}>Product not found.</div>;

  return (
    <div className="page product-detail-page">
      <div className="container">
        <Link to="/products" className="back-link">
          <ArrowLeft size={16} /> Back to products
        </Link>

        <div className="product-detail-grid">
          {/* Images */}
          <div className="product-images">
            <div className="main-image">
              <img
                src={product.images?.[activeImg] || 'https://via.placeholder.com/500'}
                alt={product.name}
              />
            </div>
            {product.images?.length > 1 && (
              <div className="thumb-list">
                {product.images.map((img, i) => (
                  <button
                    key={i}
                    className={`thumb ${activeImg === i ? 'active' : ''}`}
                    onClick={() => setActiveImg(i)}
                  >
                    <img src={img} alt="" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Info */}
          <div className="product-info">
            <div className="product-meta">
              <span className="badge badge-gray">{product.category}</span>
              {product.stock < 10 && product.stock > 0 && (
                <span className="badge badge-yellow">Only {product.stock} left</span>
              )}
              {product.stock === 0 && <span className="badge badge-red">Out of Stock</span>}
            </div>

            <h1 className="product-title">{product.name}</h1>
            <p className="product-brand">by <strong>{product.brand}</strong></p>

            <div className="product-rating">
              <div className="stars">
                {[1,2,3,4,5].map(n => (
                  <Star key={n} size={16}
                    fill={n <= Math.round(product.rating) ? 'var(--accent)' : 'none'}
                    color={n <= Math.round(product.rating) ? 'var(--accent)' : 'var(--text-3)'}
                  />
                ))}
              </div>
              <span>{product.rating?.toFixed(1)}</span>
              <span className="review-count">({product.numReviews} reviews)</span>
            </div>

            <div className="product-price-block">
              <span className="price-big">{formatPrice(product.price)}</span>
              {product.compareAtPrice && (
                <span className="price-compare-big">{formatPrice(product.compareAtPrice)}</span>
              )}
            </div>

            <p className="product-description">{product.description}</p>

            {/* Qty + Cart */}
            <div className="product-actions">
              <div className="qty-control">
                <button onClick={() => setQty(q => Math.max(1, q - 1))} disabled={qty <= 1}>
                  <Minus size={15} />
                </button>
                <span>{qty}</span>
                <button onClick={() => setQty(q => Math.min(product.stock, q + 1))} disabled={qty >= product.stock}>
                  <Plus size={15} />
                </button>
              </div>
              <button
                className="btn btn-primary btn-lg add-cart-main"
                onClick={handleAddToCart}
                disabled={product.stock === 0}
              >
                <ShoppingCart size={18} /> Add to Cart
              </button>
            </div>

            {/* Perks */}
            <div className="product-perks">
              <div className="mini-perk"><Truck size={15} /> Free shipping over $100</div>
              <div className="mini-perk"><Shield size={15} /> 30-day returns</div>
              <div className="mini-perk"><Package size={15} /> In stock: {product.stock} units</div>
            </div>
          </div>
        </div>

        {/* Reviews */}
        <div className="reviews-section">
          <h2>Customer Reviews</h2>

          {product.reviews?.length === 0 && (
            <p className="no-reviews">No reviews yet. Be the first!</p>
          )}

          <div className="reviews-list">
            {product.reviews?.map((r) => (
              <div key={r._id} className="review-card">
                <div className="review-header">
                  <div className="reviewer-avatar">{r.name.charAt(0)}</div>
                  <div>
                    <p className="reviewer-name">{r.name}</p>
                    <p className="review-date">{formatDate(r.createdAt)}</p>
                  </div>
                  <div className="review-stars">
                    {[1,2,3,4,5].map(n => (
                      <Star key={n} size={13}
                        fill={n <= r.rating ? 'var(--accent)' : 'none'}
                        color={n <= r.rating ? 'var(--accent)' : 'var(--text-3)'}
                      />
                    ))}
                  </div>
                </div>
                <p className="review-comment">{r.comment}</p>
              </div>
            ))}
          </div>

          {user && (
            <form className="review-form card" onSubmit={handleReview}>
              <h3>Write a Review</h3>
              <div className="form-group">
                <label className="form-label">Rating</label>
                <div className="star-picker">
                  {[1,2,3,4,5].map(n => (
                    <button
                      type="button"
                      key={n}
                      onClick={() => setReviewForm(f => ({ ...f, rating: n }))}
                    >
                      <Star size={22}
                        fill={n <= reviewForm.rating ? 'var(--accent)' : 'none'}
                        color={n <= reviewForm.rating ? 'var(--accent)' : 'var(--text-3)'}
                      />
                    </button>
                  ))}
                </div>
              </div>
              <div className="form-group">
                <label className="form-label">Comment</label>
                <textarea
                  className="form-input"
                  rows={4}
                  required
                  value={reviewForm.comment}
                  onChange={(e) => setReviewForm(f => ({ ...f, comment: e.target.value }))}
                  placeholder="Share your experience…"
                />
              </div>
              <button className="btn btn-primary" disabled={submitting} type="submit">
                {submitting ? 'Submitting…' : 'Submit Review'}
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
