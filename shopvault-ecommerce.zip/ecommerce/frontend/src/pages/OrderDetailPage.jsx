import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, MapPin, CreditCard } from 'lucide-react';
import api from '../utils/api';
import { formatPrice, formatDateTime, getOrderStatusColor } from '../utils/helpers';

export default function OrderDetailPage() {
  const { id } = useParams();
  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get(`/orders/${id}`)
      .then(({ data }) => setOrder(data))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [id]);

  if (loading) return <div className="loading-center"><div className="spinner" /></div>;
  if (!order) return <div className="container" style={{ padding: '60px 0', textAlign: 'center' }}>Order not found.</div>;

  return (
    <div className="page">
      <div className="container-sm">
        <Link to="/orders" className="back-link" style={{ display: 'inline-flex', alignItems: 'center', gap: 6, fontSize: 14, color: 'var(--text-2)', marginBottom: 24 }}>
          <ArrowLeft size={15} /> Back to orders
        </Link>

        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 28 }}>
          <h1 style={{ fontSize: 24 }}>Order #{order._id.slice(-8).toUpperCase()}</h1>
          <span className={`badge ${getOrderStatusColor(order.status)}`}>{order.status}</span>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 300px', gap: 20, alignItems: 'flex-start' }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            {/* Items */}
            <div className="card" style={{ padding: 20 }}>
              <h3 style={{ marginBottom: 16 }}>Items</h3>
              {order.orderItems.map((item) => (
                <div key={item._id} style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 14 }}>
                  <img src={item.image} alt={item.name} style={{ width: 60, height: 60, borderRadius: 8, objectFit: 'cover' }} />
                  <div style={{ flex: 1 }}>
                    <p style={{ fontWeight: 600, fontSize: 14 }}>{item.name}</p>
                    <p style={{ fontSize: 13, color: 'var(--text-3)' }}>Qty: {item.quantity} × {formatPrice(item.price)}</p>
                  </div>
                  <p style={{ fontFamily: 'var(--font-display)', fontWeight: 700 }}>{formatPrice(item.price * item.quantity)}</p>
                </div>
              ))}
            </div>

            {/* Shipping */}
            <div className="card" style={{ padding: 20 }}>
              <h3 style={{ marginBottom: 12, display: 'flex', alignItems: 'center', gap: 8 }}><MapPin size={16} /> Shipping Address</h3>
              <p style={{ color: 'var(--text-2)', fontSize: 14 }}>
                {order.shippingAddress.street}<br />
                {order.shippingAddress.city}, {order.shippingAddress.state} {order.shippingAddress.postalCode}<br />
                {order.shippingAddress.country}
              </p>
            </div>
          </div>

          {/* Summary */}
          <div className="card" style={{ padding: 20, position: 'sticky', top: 80 }}>
            <h3 style={{ marginBottom: 16 }}>Summary</h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {[
                ['Placed', formatDateTime(order.createdAt)],
                ['Subtotal', formatPrice(order.subtotal)],
                ['Shipping', order.shippingPrice === 0 ? 'FREE' : formatPrice(order.shippingPrice)],
                ['Tax', formatPrice(order.taxPrice)],
              ].map(([label, val]) => (
                <div key={label} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 14, color: 'var(--text-2)' }}>
                  <span>{label}</span><span>{val}</span>
                </div>
              ))}
              <div style={{ height: 1, background: 'var(--border)', margin: '6px 0' }} />
              <div style={{ display: 'flex', justifyContent: 'space-between', fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 18 }}>
                <span>Total</span><span>{formatPrice(order.totalPrice)}</span>
              </div>
            </div>
            <div style={{ marginTop: 16, display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, color: 'var(--text-2)' }}>
              <CreditCard size={14} /> {order.paymentMethod?.toUpperCase()} · {order.isPaid ? '✓ Paid' : 'Pending'}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
