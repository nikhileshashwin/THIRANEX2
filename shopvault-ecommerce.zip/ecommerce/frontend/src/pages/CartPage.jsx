import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Trash2, Plus, Minus, ShoppingBag, ArrowRight } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import { formatPrice } from '../utils/helpers';
import './CartPage.css';

export default function CartPage() {
  const { items, removeFromCart, updateQuantity, subtotal, shippingPrice, taxPrice, totalPrice, cartCount } = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();

  const handleCheckout = () => {
    if (!user) {
      navigate('/login?redirect=/checkout');
    } else {
      navigate('/checkout');
    }
  };

  if (items.length === 0) {
    return (
      <div className="page">
        <div className="container">
          <div className="cart-empty">
            <ShoppingBag size={56} className="empty-icon" />
            <h2>Your cart is empty</h2>
            <p>Add some products to get started.</p>
            <Link to="/products" className="btn btn-primary btn-lg">
              Browse Products <ArrowRight size={18} />
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="page">
      <div className="container">
        <div className="page-header">
          <h1 className="page-title">Shopping Cart</h1>
          <p className="page-subtitle">{cartCount} {cartCount === 1 ? 'item' : 'items'}</p>
        </div>

        <div className="cart-layout">
          {/* Items */}
          <div className="cart-items">
            {items.map((item) => (
              <div key={item._id} className="cart-item">
                <Link to={`/products/${item._id}`} className="cart-item-img">
                  <img
                    src={item.images?.[0] || 'https://via.placeholder.com/100'}
                    alt={item.name}
                  />
                </Link>

                <div className="cart-item-info">
                  <Link to={`/products/${item._id}`} className="cart-item-name">
                    {item.name}
                  </Link>
                  <p className="cart-item-brand">{item.brand}</p>
                  <p className="cart-item-unit">{formatPrice(item.price)} each</p>
                </div>

                <div className="cart-item-controls">
                  <div className="qty-control-sm">
                    <button onClick={() => updateQuantity(item._id, item.quantity - 1)}>
                      <Minus size={13} />
                    </button>
                    <span>{item.quantity}</span>
                    <button
                      onClick={() => updateQuantity(item._id, item.quantity + 1)}
                      disabled={item.quantity >= item.stock}
                    >
                      <Plus size={13} />
                    </button>
                  </div>

                  <p className="cart-item-total">{formatPrice(item.price * item.quantity)}</p>

                  <button
                    className="cart-remove"
                    onClick={() => removeFromCart(item._id)}
                    title="Remove"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Order Summary */}
          <div className="cart-summary card">
            <h2>Order Summary</h2>
            <div className="divider" />

            <div className="summary-rows">
              <div className="summary-row">
                <span>Subtotal</span>
                <span>{formatPrice(subtotal)}</span>
              </div>
              <div className="summary-row">
                <span>Shipping</span>
                <span>{shippingPrice === 0 ? <span className="free-tag">FREE</span> : formatPrice(shippingPrice)}</span>
              </div>
              <div className="summary-row">
                <span>Tax (8%)</span>
                <span>{formatPrice(taxPrice)}</span>
              </div>
            </div>

            <div className="divider" />
            <div className="summary-row total-row">
              <span>Total</span>
              <span>{formatPrice(totalPrice)}</span>
            </div>

            {shippingPrice > 0 && (
              <p className="shipping-note">
                Add {formatPrice(100 - subtotal)} more for free shipping!
              </p>
            )}

            <button
              className="btn btn-primary btn-lg checkout-btn"
              onClick={handleCheckout}
            >
              Proceed to Checkout <ArrowRight size={18} />
            </button>

            <Link to="/products" className="btn btn-ghost" style={{ textAlign: 'center', justifyContent: 'center' }}>
              Continue Shopping
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
