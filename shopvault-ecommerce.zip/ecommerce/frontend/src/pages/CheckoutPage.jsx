import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CreditCard, MapPin, CheckCircle } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import api from '../utils/api';
import { formatPrice } from '../utils/helpers';
import toast from 'react-hot-toast';
import './CheckoutPage.css';

const STEPS = ['Shipping', 'Review', 'Payment'];

export default function CheckoutPage() {
  const { items, subtotal, shippingPrice, taxPrice, totalPrice, clearCart } = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();

  const [step, setStep] = useState(0);
  const [placing, setPlacing] = useState(false);
  const [address, setAddress] = useState({
    street: '', city: '', state: '', postalCode: '', country: 'US',
  });

  const handleAddressChange = (e) => {
    setAddress((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleAddressSubmit = (e) => {
    e.preventDefault();
    const { street, city, state, postalCode } = address;
    if (!street || !city || !state || !postalCode) {
      toast.error('Please fill all address fields');
      return;
    }
    setStep(1);
  };

  const placeOrder = async () => {
    setPlacing(true);
    try {
      const orderItems = items.map((item) => ({
        product: item._id,
        name: item.name,
        image: item.images?.[0],
        price: item.price,
        quantity: item.quantity,
      }));

      const { data } = await api.post('/orders', {
        orderItems,
        shippingAddress: address,
        paymentMethod: 'cod',
      });

      clearCart();
      toast.success('Order placed successfully!');
      navigate(`/order-success/${data._id}`);
    } catch (err) {
      toast.error(err?.response?.data?.message || 'Failed to place order');
    } finally {
      setPlacing(false);
    }
  };

  if (items.length === 0) {
    navigate('/cart');
    return null;
  }

  return (
    <div className="page checkout-page">
      <div className="container-sm">
        <h1 className="page-title">Checkout</h1>

        {/* Step indicator */}
        <div className="steps-bar">
          {STEPS.map((s, i) => (
            <React.Fragment key={s}>
              <div className={`step ${i <= step ? 'active' : ''} ${i < step ? 'done' : ''}`}>
                <div className="step-dot">
                  {i < step ? <CheckCircle size={18} /> : <span>{i + 1}</span>}
                </div>
                <span className="step-label">{s}</span>
              </div>
              {i < STEPS.length - 1 && <div className={`step-line ${i < step ? 'done' : ''}`} />}
            </React.Fragment>
          ))}
        </div>

        <div className="checkout-layout">
          {/* Left panel */}
          <div className="checkout-form">
            {/* Step 0: Shipping */}
            {step === 0 && (
              <form className="card checkout-card" onSubmit={handleAddressSubmit}>
                <div className="checkout-section-title">
                  <MapPin size={18} /> Shipping Address
                </div>
                <div className="form-grid">
                  <div className="form-group" style={{ gridColumn: '1 / -1' }}>
                    <label className="form-label">Street Address</label>
                    <input name="street" className="form-input" value={address.street} onChange={handleAddressChange} placeholder="123 Main St" required />
                  </div>
                  <div className="form-group">
                    <label className="form-label">City</label>
                    <input name="city" className="form-input" value={address.city} onChange={handleAddressChange} placeholder="New York" required />
                  </div>
                  <div className="form-group">
                    <label className="form-label">State</label>
                    <input name="state" className="form-input" value={address.state} onChange={handleAddressChange} placeholder="NY" required />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Postal Code</label>
                    <input name="postalCode" className="form-input" value={address.postalCode} onChange={handleAddressChange} placeholder="10001" required />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Country</label>
                    <select name="country" className="form-select" value={address.country} onChange={handleAddressChange}>
                      <option value="US">United States</option>
                      <option value="CA">Canada</option>
                      <option value="GB">United Kingdom</option>
                      <option value="AU">Australia</option>
                    </select>
                  </div>
                </div>
                <button type="submit" className="btn btn-primary btn-lg" style={{ width: '100%' }}>
                  Continue to Review
                </button>
              </form>
            )}

            {/* Step 1: Review */}
            {step === 1 && (
              <div className="card checkout-card">
                <div className="checkout-section-title">Order Review</div>
                <div className="review-items">
                  {items.map((item) => (
                    <div key={item._id} className="review-item">
                      <img src={item.images?.[0]} alt={item.name} />
                      <div className="review-item-info">
                        <p className="review-item-name">{item.name}</p>
                        <p className="review-item-qty">Qty: {item.quantity}</p>
                      </div>
                      <p className="review-item-price">{formatPrice(item.price * item.quantity)}</p>
                    </div>
                  ))}
                </div>
                <div className="divider" />
                <div className="address-summary">
                  <p className="address-label">Shipping to:</p>
                  <p>{address.street}, {address.city}, {address.state} {address.postalCode}, {address.country}</p>
                </div>
                <div className="checkout-btn-row">
                  <button className="btn btn-outline" onClick={() => setStep(0)}>← Back</button>
                  <button className="btn btn-primary btn-lg" onClick={() => setStep(2)}>
                    Continue to Payment
                  </button>
                </div>
              </div>
            )}

            {/* Step 2: Payment */}
            {step === 2 && (
              <div className="card checkout-card">
                <div className="checkout-section-title">
                  <CreditCard size={18} /> Payment Method
                </div>
                <div className="payment-option selected">
                  <input type="radio" checked readOnly id="cod" />
                  <label htmlFor="cod">
                    <strong>Cash on Delivery</strong>
                    <span>Pay when your order arrives</span>
                  </label>
                </div>
                <p className="payment-note">
                  Stripe integration is pre-configured. Add your keys in <code>.env</code> to enable card payments.
                </p>
                <div className="checkout-btn-row">
                  <button className="btn btn-outline" onClick={() => setStep(1)}>← Back</button>
                  <button
                    className="btn btn-primary btn-lg"
                    onClick={placeOrder}
                    disabled={placing}
                  >
                    {placing ? 'Placing Order…' : `Place Order · ${formatPrice(totalPrice)}`}
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Order summary sidebar */}
          <div className="checkout-summary card">
            <h3>Summary</h3>
            <div className="divider" />
            <div className="summary-rows">
              <div className="summary-row"><span>Subtotal ({items.length})</span><span>{formatPrice(subtotal)}</span></div>
              <div className="summary-row"><span>Shipping</span><span>{shippingPrice === 0 ? 'FREE' : formatPrice(shippingPrice)}</span></div>
              <div className="summary-row"><span>Tax</span><span>{formatPrice(taxPrice)}</span></div>
            </div>
            <div className="divider" />
            <div className="summary-row total-row"><span>Total</span><span>{formatPrice(totalPrice)}</span></div>
          </div>
        </div>
      </div>
    </div>
  );
}
