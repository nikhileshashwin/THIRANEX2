import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Zap, Shield, Truck, RotateCcw } from 'lucide-react';
import api from '../utils/api';
import ProductCard from '../components/ProductCard';
import './HomePage.css';

const CATEGORIES = [
  { name: 'Electronics', icon: '💻', color: '#5b8def' },
  { name: 'Fashion', icon: '👗', color: '#e85aab' },
  { name: 'Sports', icon: '⚽', color: '#4caf78' },
  { name: 'Home & Kitchen', icon: '🏠', color: '#e8a547' },
];

const PERKS = [
  { icon: <Truck size={22} />, title: 'Free Shipping', desc: 'On orders over $100' },
  { icon: <Shield size={22} />, title: 'Secure Payments', desc: 'SSL encrypted checkout' },
  { icon: <RotateCcw size={22} />, title: '30-Day Returns', desc: 'Hassle-free returns' },
  { icon: <Zap size={22} />, title: 'Fast Delivery', desc: '2–5 business days' },
];

export default function HomePage() {
  const [featured, setFeatured] = useState([]);
  const [newest, setNewest] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const [featRes, newRes] = await Promise.all([
          api.get('/products?limit=4&sort=rating'),
          api.get('/products?limit=8&sort=newest'),
        ]);
        setFeatured(featRes.data.products);
        setNewest(newRes.data.products);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchProducts();
  }, []);

  return (
    <div className="home">
      {/* Hero */}
      <section className="hero">
        <div className="container hero-inner">
          <div className="hero-content">
            <div className="hero-tag badge badge-yellow">New Season Arrivals</div>
            <h1 className="hero-title">
              Discover <span className="hero-highlight">Premium</span><br />
              Products Online
            </h1>
            <p className="hero-desc">
              Shop thousands of curated products across electronics, fashion, sports and more.
              Fast shipping. Easy returns.
            </p>
            <div className="hero-cta">
              <Link to="/products" className="btn btn-primary btn-lg">
                Shop Now <ArrowRight size={18} />
              </Link>
              <Link to="/products?category=Electronics" className="btn btn-outline btn-lg">
                Browse Electronics
              </Link>
            </div>
            <div className="hero-stats">
              <div className="stat"><strong>10K+</strong><span>Products</span></div>
              <div className="stat-divider" />
              <div className="stat"><strong>50K+</strong><span>Customers</span></div>
              <div className="stat-divider" />
              <div className="stat"><strong>4.8★</strong><span>Rating</span></div>
            </div>
          </div>
          <div className="hero-visual">
            <div className="hero-blob" />
            <img
              src="https://images.unsplash.com/photo-1483985988355-763728e1935b?w=600&auto=format&fit=crop"
              alt="Shopping"
              className="hero-img"
            />
          </div>
        </div>
      </section>

      {/* Perks */}
      <section className="perks-bar">
        <div className="container perks-inner">
          {PERKS.map((p, i) => (
            <div key={i} className="perk">
              <span className="perk-icon">{p.icon}</span>
              <div>
                <p className="perk-title">{p.title}</p>
                <p className="perk-desc">{p.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Categories */}
      <section className="section">
        <div className="container">
          <div className="section-header">
            <h2>Shop by Category</h2>
            <Link to="/products" className="see-all">View all <ArrowRight size={14} /></Link>
          </div>
          <div className="category-grid">
            {CATEGORIES.map((cat) => (
              <Link
                key={cat.name}
                to={`/products?category=${cat.name}`}
                className="category-card"
                style={{ '--cat-color': cat.color }}
              >
                <span className="cat-icon">{cat.icon}</span>
                <span className="cat-name">{cat.name}</span>
                <ArrowRight size={14} className="cat-arrow" />
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Top Rated */}
      {!loading && featured.length > 0 && (
        <section className="section">
          <div className="container">
            <div className="section-header">
              <h2>Top Rated</h2>
              <Link to="/products?sort=rating" className="see-all">View all <ArrowRight size={14} /></Link>
            </div>
            <div className="product-grid">
              {featured.map((p) => <ProductCard key={p._id} product={p} />)}
            </div>
          </div>
        </section>
      )}

      {/* Newest */}
      <section className="section">
        <div className="container">
          <div className="section-header">
            <h2>Just Arrived</h2>
            <Link to="/products?sort=newest" className="see-all">View all <ArrowRight size={14} /></Link>
          </div>
          {loading ? (
            <div className="loading-center"><div className="spinner" /></div>
          ) : (
            <div className="product-grid">
              {newest.map((p) => <ProductCard key={p._id} product={p} />)}
            </div>
          )}
        </div>
      </section>

      {/* CTA Banner */}
      <section className="cta-banner">
        <div className="container cta-inner">
          <div>
            <h2>Ready to start shopping?</h2>
            <p>Create a free account and get exclusive deals.</p>
          </div>
          <Link to="/register" className="btn btn-primary btn-lg">
            Get Started <ArrowRight size={18} />
          </Link>
        </div>
      </section>
    </div>
  );
}
