import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Package, ChevronRight } from 'lucide-react';
import api from '../utils/api';
import { formatPrice, formatDate, getOrderStatusColor } from '../utils/helpers';

export default function OrdersPage() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/orders/my')
      .then(({ data }) => setOrders(data.orders))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="page">
      <div className="container-sm">
        <div className="page-header">
          <h1 className="page-title">My Orders</h1>
          <p className="page-subtitle">{orders.length} orders</p>
        </div>

        {loading ? (
          <div className="loading-center"><div className="spinner" /></div>
        ) : orders.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '60px 0', color: 'var(--text-2)' }}>
            <Package size={48} style={{ margin: '0 auto 16px', color: 'var(--text-3)' }} />
            <p>No orders yet.</p>
            <Link to="/products" className="btn btn-primary" style={{ marginTop: 16 }}>Start Shopping</Link>
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {orders.map((order) => (
              <Link key={order._id} to={`/orders/${order._id}`} className="card" style={{ padding: 20, display: 'flex', alignItems: 'center', gap: 16, transition: 'border-color 0.2s', textDecoration: 'none' }}>
                <div style={{ flex: 1 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 6 }}>
                    <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 15 }}>
                      #{order._id.slice(-8).toUpperCase()}
                    </span>
                    <span className={`badge ${getOrderStatusColor(order.status)}`}>{order.status}</span>
                  </div>
                  <p style={{ fontSize: 13, color: 'var(--text-3)' }}>{formatDate(order.createdAt)} · {order.orderItems.length} item(s)</p>
                </div>
                <p style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 17 }}>{formatPrice(order.totalPrice)}</p>
                <ChevronRight size={18} style={{ color: 'var(--text-3)' }} />
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
