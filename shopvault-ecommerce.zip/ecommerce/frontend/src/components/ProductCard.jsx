import React from 'react';
import { Link } from 'react-router-dom';
import { ShoppingCart, Star } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { formatPrice, calcDiscount } from '../utils/helpers';
import './ProductCard.css';

export default function ProductCard({ product }) {
  const { addToCart } = useCart();

  const discount = calcDiscount(product.price, product.compareAtPrice);

  return (
    <div className="product-card fade-in">
      <Link to={`/products/${product._id}`} className="product-card-img-wrap">
        <img
          src={product.images?.[0] || 'https://via.placeholder.com/300x300?text=No+Image'}
          alt={product.name}
          className="product-card-img"
          loading="lazy"
        />
        {discount && <span className="product-discount-badge">-{discount}%</span>}
        {product.stock === 0 && (
          <div className="product-out-overlay">Out of Stock</div>
        )}
      </Link>

      <div className="product-card-body">
        <p className="product-card-brand">{product.brand}</p>
        <Link to={`/products/${product._id}`} className="product-card-name">
          {product.name}
        </Link>

        <div className="product-card-rating">
          <Star size={12} fill="var(--accent)" color="var(--accent)" />
          <span>{product.rating?.toFixed(1)}</span>
          <span className="rating-count">({product.numReviews})</span>
        </div>

        <div className="product-card-footer">
          <div className="product-card-price">
            <span className="price-main">{formatPrice(product.price)}</span>
            {product.compareAtPrice && (
              <span className="price-compare">{formatPrice(product.compareAtPrice)}</span>
            )}
          </div>
          <button
            className="add-to-cart-btn"
            onClick={(e) => { e.preventDefault(); addToCart(product); }}
            disabled={product.stock === 0}
            title="Add to cart"
          >
            <ShoppingCart size={16} />
          </button>
        </div>
      </div>
    </div>
  );
}
