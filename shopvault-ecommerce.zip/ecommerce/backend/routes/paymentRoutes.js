const express = require('express');
const router = express.Router();
const { createPaymentIntent, stripeWebhook } = require('../controllers/paymentController');
const { protect } = require('../middleware/authMiddleware');

router.post('/create-intent', protect, createPaymentIntent);
// Stripe needs raw body for webhook signature verification
router.post('/webhook', express.raw({ type: 'application/json' }), stripeWebhook);

module.exports = router;
