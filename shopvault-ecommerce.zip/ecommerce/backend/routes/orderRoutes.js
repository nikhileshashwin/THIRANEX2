const express = require('express');
const router = express.Router();
const {
  createOrder, getMyOrders, getOrderById, markOrderPaid,
  getAllOrders, updateOrderStatus, getOrderStats,
} = require('../controllers/orderController');
const { protect, adminOnly } = require('../middleware/authMiddleware');
const { orderValidation } = require('../middleware/validationMiddleware');

router.post('/', protect, orderValidation, createOrder);
router.get('/my', protect, getMyOrders);
router.get('/stats', protect, adminOnly, getOrderStats);
router.get('/', protect, adminOnly, getAllOrders);
router.get('/:id', protect, getOrderById);
router.put('/:id/pay', protect, markOrderPaid);
router.put('/:id/status', protect, adminOnly, updateOrderStatus);

module.exports = router;
