const express = require('express');
const router = express.Router();
const {
  getProducts, getProductById, createProduct, updateProduct,
  deleteProduct, createReview, getCategories, getAdminProducts,
} = require('../controllers/productController');
const { protect, adminOnly } = require('../middleware/authMiddleware');
const { productValidation } = require('../middleware/validationMiddleware');

router.get('/categories', getCategories);
router.get('/admin/all', protect, adminOnly, getAdminProducts);
router.get('/', getProducts);
router.get('/:id', getProductById);
router.post('/', protect, adminOnly, productValidation, createProduct);
router.put('/:id', protect, adminOnly, updateProduct);
router.delete('/:id', protect, adminOnly, deleteProduct);
router.post('/:id/reviews', protect, createReview);

module.exports = router;
