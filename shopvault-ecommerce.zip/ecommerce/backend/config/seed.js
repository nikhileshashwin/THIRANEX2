require('dotenv').config({ path: '../.env' });
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const User = require('../models/User');
const Product = require('../models/Product');

const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/shopvault';

const users = [
  {
    name: 'Admin User',
    email: 'admin@shopvault.com',
    password: 'Admin@123',
    role: 'admin',
  },
  {
    name: 'John Doe',
    email: 'user@shopvault.com',
    password: 'User@123',
    role: 'user',
  },
];

const products = [
  {
    name: 'Wireless Noise-Cancelling Headphones',
    description: 'Premium over-ear headphones with 30-hour battery life and studio-quality sound.',
    price: 299.99,
    category: 'Electronics',
    brand: 'SoundWave',
    stock: 45,
    images: ['https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400'],
    rating: 4.7,
    numReviews: 128,
  },
  {
    name: 'Ultra-Slim Laptop 15"',
    description: 'Powerful lightweight laptop with 16GB RAM, 512GB SSD, and all-day battery.',
    price: 1199.99,
    category: 'Electronics',
    brand: 'TechPro',
    stock: 20,
    images: ['https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=400'],
    rating: 4.5,
    numReviews: 89,
  },
  {
    name: 'Mechanical Gaming Keyboard',
    description: 'RGB backlit mechanical keyboard with Cherry MX switches and anti-ghosting.',
    price: 129.99,
    category: 'Electronics',
    brand: 'GameForge',
    stock: 60,
    images: ['https://images.unsplash.com/photo-1541140532154-b024d705b90a?w=400'],
    rating: 4.6,
    numReviews: 215,
  },
  {
    name: 'Smart Watch Series X',
    description: 'Health tracking, GPS, AMOLED display, and 5-day battery in a sleek design.',
    price: 399.99,
    category: 'Electronics',
    brand: 'TimeTech',
    stock: 35,
    images: ['https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400'],
    rating: 4.4,
    numReviews: 307,
  },
  {
    name: 'Premium Running Shoes',
    description: 'Lightweight, breathable mesh with responsive cushioning for all terrains.',
    price: 149.99,
    category: 'Sports',
    brand: 'StridePro',
    stock: 80,
    images: ['https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400'],
    rating: 4.8,
    numReviews: 456,
  },
  {
    name: 'Yoga Mat Premium',
    description: '6mm thick non-slip eco-friendly yoga mat with alignment lines.',
    price: 49.99,
    category: 'Sports',
    brand: 'ZenFlex',
    stock: 120,
    images: ['https://images.unsplash.com/photo-1601925260368-ae2f83cf8b7f?w=400'],
    rating: 4.3,
    numReviews: 183,
  },
  {
    name: 'Stainless Steel Water Bottle',
    description: 'Double-wall vacuum insulated, keeps drinks cold 24hr or hot 12hr. 32oz.',
    price: 34.99,
    category: 'Sports',
    brand: 'HydraFlow',
    stock: 200,
    images: ['https://images.unsplash.com/photo-1602143407151-7111542de6e8?w=400'],
    rating: 4.6,
    numReviews: 624,
  },
  {
    name: 'Designer Leather Backpack',
    description: 'Full-grain leather laptop backpack with USB charging port. Fits 15" laptop.',
    price: 189.99,
    category: 'Fashion',
    brand: 'UrbanCraft',
    stock: 40,
    images: ['https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=400'],
    rating: 4.5,
    numReviews: 97,
  },
  {
    name: 'Polarized Sunglasses',
    description: 'UV400 protection, lightweight titanium frame, polarized lenses.',
    price: 89.99,
    category: 'Fashion',
    brand: 'VistaClear',
    stock: 75,
    images: ['https://images.unsplash.com/photo-1572635196237-14b3f281503f?w=400'],
    rating: 4.2,
    numReviews: 162,
  },
  {
    name: 'Ceramic Pour-Over Coffee Set',
    description: 'Hand-crafted ceramic dripper with server, filters, and measuring spoon.',
    price: 64.99,
    category: 'Home & Kitchen',
    brand: 'BrewMaster',
    stock: 55,
    images: ['https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=400'],
    rating: 4.7,
    numReviews: 241,
  },
  {
    name: 'Wireless Charging Pad',
    description: '15W fast wireless charger compatible with all Qi-enabled devices.',
    price: 39.99,
    category: 'Electronics',
    brand: 'PowerFlow',
    stock: 150,
    images: ['https://images.unsplash.com/photo-1583394838336-acd977736f90?w=400'],
    rating: 4.3,
    numReviews: 388,
  },
  {
    name: 'Aromatherapy Diffuser',
    description: 'Ultrasonic essential oil diffuser with 7-color LED, timer, and 400ml capacity.',
    price: 44.99,
    category: 'Home & Kitchen',
    brand: 'AuraScent',
    stock: 90,
    images: ['https://images.unsplash.com/photo-1608571423902-eed4a5ad8108?w=400'],
    rating: 4.4,
    numReviews: 172,
  },
];

async function seedDB() {
  try {
    await mongoose.connect(MONGO_URI);
    console.log('✅ Connected to MongoDB');

    // Clear existing
    await User.deleteMany({});
    await Product.deleteMany({});
    console.log('🗑️  Cleared existing data');

    // Seed users (passwords hashed in pre-save hook)
    const createdUsers = await User.insertMany(
      users.map(u => ({ ...u }))
    );
    // Manually hash since insertMany bypasses middleware
    for (const u of createdUsers) {
      u.password = await bcrypt.hash(
        users.find(x => x.email === u.email).password,
        12
      );
      await u.save();
    }
    console.log(`👤 Seeded ${createdUsers.length} users`);

    // Seed products
    const adminUser = createdUsers.find(u => u.role === 'admin');
    const productsWithCreator = products.map(p => ({ ...p, createdBy: adminUser._id }));
    await Product.insertMany(productsWithCreator);
    console.log(`📦 Seeded ${products.length} products`);

    console.log('\n🎉 Database seeded successfully!');
    console.log('──────────────────────────────');
    console.log('Admin: admin@shopvault.com / Admin@123');
    console.log('User:  user@shopvault.com  / User@123');
    console.log('──────────────────────────────');
    process.exit(0);
  } catch (err) {
    console.error('❌ Seed error:', err);
    process.exit(1);
  }
}

seedDB();
