# 🛒 ShopVault — Full-Stack E-Commerce Application

A production-ready e-commerce platform with product management, cart, checkout, user auth, and admin dashboard.

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 18, React Router v6, Tailwind CSS |
| Backend | Node.js, Express.js |
| Database | MongoDB (Mongoose ODM) |
| Auth | JWT (Access + Refresh Tokens) |
| Payments | Stripe (test mode) |

---

## Project Structure

```
ecommerce/
├── backend/
│   ├── config/          # DB & env config
│   ├── controllers/     # Route logic
│   ├── middleware/      # Auth, error handling
│   ├── models/          # Mongoose schemas
│   ├── routes/          # Express routers
│   └── server.js
├── frontend/
│   ├── public/
│   └── src/
│       ├── components/  # Reusable UI
│       ├── context/     # React Context (Auth, Cart)
│       ├── hooks/       # Custom hooks
│       ├── pages/       # Route-level pages
│       └── utils/       # API helpers
└── README.md
```

---

## Quick Start

### Prerequisites
- Node.js >= 18
- MongoDB Atlas URI **or** local MongoDB
- Stripe account (test keys)

### 1. Clone & Install

```bash
git clone https://github.com/YOUR_USERNAME/shopvault.git
cd shopvault

# Backend deps
cd backend && npm install

# Frontend deps
cd ../frontend && npm install
```

### 2. Environment Variables

**backend/.env**
```
PORT=5000
MONGO_URI=mongodb+srv://<user>:<pass>@cluster.mongodb.net/shopvault
JWT_SECRET=your_super_secret_jwt_key
JWT_REFRESH_SECRET=your_refresh_secret
STRIPE_SECRET_KEY=sk_test_...
CLIENT_URL=http://localhost:3000
NODE_ENV=development
```

**frontend/.env**
```
REACT_APP_API_URL=http://localhost:5000/api
REACT_APP_STRIPE_PUBLIC_KEY=pk_test_...
```

### 3. Seed Database

```bash
cd backend
npm run seed
```

This creates:
- **Admin**: admin@shopvault.com / Admin@123
- **User**: user@shopvault.com / User@123
- 12 sample products

### 4. Run Development Servers

```bash
# Terminal 1 — Backend (port 5000)
cd backend && npm run dev

# Terminal 2 — Frontend (port 3000)
cd frontend && npm start
```

---

## API Endpoints

### Auth
| Method | Endpoint | Access |
|--------|----------|--------|
| POST | /api/auth/register | Public |
| POST | /api/auth/login | Public |
| POST | /api/auth/refresh | Public |
| POST | /api/auth/logout | Private |
| GET | /api/auth/me | Private |

### Products
| Method | Endpoint | Access |
|--------|----------|--------|
| GET | /api/products | Public |
| GET | /api/products/:id | Public |
| POST | /api/products | Admin |
| PUT | /api/products/:id | Admin |
| DELETE | /api/products/:id | Admin |

### Orders
| Method | Endpoint | Access |
|--------|----------|--------|
| POST | /api/orders | Private |
| GET | /api/orders/my | Private |
| GET | /api/orders/:id | Private |
| GET | /api/orders | Admin |
| PUT | /api/orders/:id/status | Admin |

### Users (Admin)
| Method | Endpoint | Access |
|--------|----------|--------|
| GET | /api/users | Admin |
| GET | /api/users/:id | Admin |
| PUT | /api/users/:id | Admin |
| DELETE | /api/users/:id | Admin |

---

## Roles

- **User** — Browse, cart, checkout, view own orders
- **Admin** — All user permissions + product CRUD, all orders, user management

---

## Deployment

### Backend → Railway / Render
1. Set all env vars in platform dashboard
2. Build command: `npm install`
3. Start command: `node server.js`

### Frontend → Vercel / Netlify
1. Set `REACT_APP_API_URL` to deployed backend URL
2. Build command: `npm run build`
3. Publish dir: `build`

---

## License
MIT
